# Conecta Cultura

Proyecto incremental de la asignatura Desarrollo FullStack II.

## Primera etapa
- Estructura HTML inicial.
- Hoja de estilos externa.
- Archivo JavaScript enlazado.

## Ejecución
Abrir `index.html` en el navegador o utilizar Live Server.

## Bibliografia
https://www.ionos.com/es-us/digitalguide/fileadmin/DigitalGuide/Teaser/exif-t.jpg
https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkbLfa5rgdKQLE-JtlovgARJQ4oSYq-R-EoIGm4PsQZw&s=10
https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTyqQbVhRZ7IT5dnZTiOXJLLCtGjfGrvI2NVxLkOfCfg&s=10